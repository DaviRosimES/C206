package interfaces;

public interface Lutar {
    void atacar();
    void defender();
}
