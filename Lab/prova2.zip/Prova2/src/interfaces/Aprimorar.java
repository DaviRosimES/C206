package interfaces;

public interface Aprimorar {
    void modificarArma();
    void modificarHabilidade(int qtdPilulas, String tipoHabilidade);
}
