package interfaces;

public interface Infectar {
    void infectou();
}
