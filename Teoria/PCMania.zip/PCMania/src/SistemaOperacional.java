public class SistemaOperacional {
    String nome;
    int tipo;
}
