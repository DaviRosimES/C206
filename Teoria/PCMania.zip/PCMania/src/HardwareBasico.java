public class HardwareBasico {
    String nome;
    float capacidade;

}
