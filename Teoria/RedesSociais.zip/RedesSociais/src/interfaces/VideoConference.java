package interfaces;

public interface VideoConference {
    void stream();
}
