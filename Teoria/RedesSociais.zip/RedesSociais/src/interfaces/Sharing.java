package interfaces;

public interface Sharing {
    void share();
}
